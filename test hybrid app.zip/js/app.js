$.post('https://kinative.com/test_hybrid_app/contact_process.php', {

    // These are the names of the form values

    FirstName: $('#FirstName_input').val(), 
    Email: $('#Email_input').val(),
    MessageText: $('#MessageText_input').val()

    // HTML function

    }, function (html) {
        // Place the HTML in a astring
        var response=html;

        // PHP was done and email sent
        if (response=="success") {
            alert("Message sent!"); 
        } else {

            // Error postback
            alert("Sorry please fill all fields!"); 
        return false;
    }
}); 